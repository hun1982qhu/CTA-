from .widget import SpreadManager
